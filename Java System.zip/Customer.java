package mypackage.System;

public class Customer {
    private int id;
    private String name;
    private String contact;
    private String email;
    private int totalVisits;

    public Customer(int id, String name, String contact, String email, int totalVisits) {
        this.id          = id;
        this.name        = name;
        this.contact     = contact;
        this.email       = email;
        this.totalVisits = totalVisits;
    }

    public int    getId()          { return id; }
    public String getName()        { return name; }
    public String getContact()     { return contact; }
    public String getEmail()       { return email; }
    public int    getTotalVisits() { return totalVisits; }

    public void setName(String v)        { name        = v; }
    public void setContact(String v)     { contact     = v; }
    public void setEmail(String v)       { email       = v; }
    public void setTotalVisits(int v)    { totalVisits = v; }
}
