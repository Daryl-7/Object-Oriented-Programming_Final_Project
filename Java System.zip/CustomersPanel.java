package mypackage.System;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.List;

public class CustomersPanel extends JPanel {

    private DefaultTableModel model;
    private StyledTable table;
    private List<Customer> data;

    private JTextField searchField;

    private JTextField fName, fContact, fEmail, fVisits;
    private JButton btnSave, btnClear, btnDelete;
    private int editingId = -1;

    public CustomersPanel() {
        setLayout(new BorderLayout());
        setBackground(Theme.MAIN_BG);
        build();
    }

    private void build() {
        JPanel wrapper = new JPanel(new BorderLayout(0, 16));
        wrapper.setBackground(Theme.MAIN_BG);
        wrapper.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        wrapper.add(buildTableSection(), BorderLayout.CENTER);
        wrapper.add(buildForm(),         BorderLayout.SOUTH);
        add(wrapper, BorderLayout.CENTER);
    }

    private JPanel buildTableSection() {
        JPanel panel = new JPanel(new BorderLayout(0, 10));
        panel.setBackground(Theme.MAIN_BG);

        JPanel hdr = new JPanel(new BorderLayout(10, 0));
        hdr.setBackground(Theme.MAIN_BG);
        hdr.add(Theme.sectionTitle("Customers"), BorderLayout.WEST);

        // --- Search bar ---
        searchField = Theme.inputField();
        searchField.setToolTipText("Search by name, contact, or email");
        searchField.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                filterTable(searchField.getText().trim());
            }
        });
        JPanel searchWrap = new JPanel(new BorderLayout());
        searchWrap.setBackground(Theme.MAIN_BG);
        searchWrap.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 10));
        searchWrap.add(searchField, BorderLayout.CENTER);
        hdr.add(searchWrap, BorderLayout.CENTER);

        JButton btnRefresh = Theme.secondaryBtn("Refresh");
        btnRefresh.addActionListener(e -> { searchField.setText(""); refreshTable(); });
        hdr.add(btnRefresh, BorderLayout.EAST);
        panel.add(hdr, BorderLayout.NORTH);

        String[] cols = {"ID", "Name", "Contact", "Email", "Total Visits"};
        model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new StyledTable(model);
        table.getColumnModel().getColumn(0).setPreferredWidth(40);
        table.getColumnModel().getColumn(1).setPreferredWidth(170);
        table.getColumnModel().getColumn(2).setPreferredWidth(120);
        table.getColumnModel().getColumn(3).setPreferredWidth(180);
        table.getColumnModel().getColumn(4).setPreferredWidth(90);

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                Customer c = data.get(table.getSelectedRow());
                populateForm(c);
            }
        });

        JScrollPane sp = table.inScrollPane();
        sp.setPreferredSize(new Dimension(0, 240));
        panel.add(sp, BorderLayout.CENTER);
        refreshTable();
        return panel;
    }

    private JPanel buildForm() {
        JPanel card = new JPanel(new BorderLayout(0, 12));
        card.setBackground(Theme.CARD_BG);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Theme.CARD_BORDER, 1),
            BorderFactory.createEmptyBorder(14, 16, 14, 16)
        ));

        JPanel titleRow = new JPanel(new BorderLayout());
        titleRow.setBackground(Theme.CARD_BG);
        titleRow.add(Theme.sectionTitle("Add / Edit Customer"), BorderLayout.WEST);
        card.add(titleRow, BorderLayout.NORTH);

        fName    = Theme.inputField();
        fContact = Theme.inputField();
        fEmail   = Theme.inputField();
        fVisits  = Theme.inputField();

        JPanel grid = new JPanel(new GridLayout(1, 4, 14, 10));
        grid.setBackground(Theme.CARD_BG);
        grid.add(fieldBlock("Full Name", fName));
        grid.add(fieldBlock("Contact", fContact));
        grid.add(fieldBlock("Email", fEmail));
        grid.add(fieldBlock("Total Visits", fVisits));

        card.add(grid, BorderLayout.CENTER);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setBackground(Theme.CARD_BG);

        btnDelete = Theme.secondaryBtn("Delete");
        btnDelete.setForeground(new Color(198, 40, 40));
        btnDelete.setVisible(false);
        btnDelete.addActionListener(e -> deleteSelected());

        btnClear = Theme.secondaryBtn("Clear");
        btnClear.addActionListener(e -> clearForm());

        btnSave = Theme.primaryBtn("Save Customer");
        btnSave.addActionListener(e -> saveCustomer());

        btnRow.add(btnDelete); btnRow.add(btnClear); btnRow.add(btnSave);
        card.add(btnRow, BorderLayout.SOUTH);

        return card;
    }

    private JPanel fieldBlock(String labelText, JComponent field) {
        JPanel block = new JPanel();
        block.setLayout(new BoxLayout(block, BoxLayout.Y_AXIS));
        block.setBackground(Theme.CARD_BG);

        JLabel label = Theme.formLabel(labelText);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);

        field.setAlignmentX(Component.LEFT_ALIGNMENT);
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));
        field.setPreferredSize(new Dimension(field.getPreferredSize().width, 30));

        block.add(label);
        block.add(Box.createVerticalStrut(4));
        block.add(field);
        return block;
    }

    private void refreshTable() {
        model.setRowCount(0);
        data = CustomerDAO.getAll();
        for (Customer c : data) {
            model.addRow(new Object[]{c.getId(), c.getName(), c.getContact(), c.getEmail(), c.getTotalVisits()});
        }
    }

    /**
     * Filters the table in-memory based on name, contact, or email.
     * Does not touch the database — just re-renders rows that match.
     */
    private void filterTable(String keyword) {
        model.setRowCount(0);
        String lower = keyword.toLowerCase();
        for (Customer c : data) {
            boolean matches = keyword.isEmpty()
                || c.getName().toLowerCase().contains(lower)
                || c.getContact().contains(keyword)
                || (c.getEmail() != null && c.getEmail().toLowerCase().contains(lower));
            if (matches) {
                model.addRow(new Object[]{c.getId(), c.getName(), c.getContact(), c.getEmail(), c.getTotalVisits()});
            }
        }
    }

    private void populateForm(Customer c) {
        editingId = c.getId();
        fName.setText(c.getName());
        fContact.setText(c.getContact());
        fEmail.setText(c.getEmail());
        fVisits.setText(String.valueOf(c.getTotalVisits()));
        btnSave.setText("Update Customer");
        btnDelete.setVisible(true);
    }

    private void clearForm() {
        editingId = -1;
        fName.setText(""); fContact.setText(""); fEmail.setText(""); fVisits.setText("");
        btnSave.setText("Save Customer");
        btnDelete.setVisible(false);
        table.clearSelection();
    }

    private void saveCustomer() {
        String name    = fName.getText().trim();
        String contact = fContact.getText().trim();
        String email   = fEmail.getText().trim();
        int visits = 0;

        if (name.isEmpty() || contact.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Name and Contact are required.", "Incomplete", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try { if (!fVisits.getText().trim().isEmpty()) visits = Integer.parseInt(fVisits.getText().trim()); }
        catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Total visits must be a number.", "Invalid", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Customer c = new Customer(editingId, name, contact, email, visits);
        if (editingId == -1) {
            CustomerDAO.add(c);
            JOptionPane.showMessageDialog(this, "Customer added!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } else {
            CustomerDAO.update(c);
            JOptionPane.showMessageDialog(this, "Customer updated!", "Success", JOptionPane.INFORMATION_MESSAGE);
        }
        clearForm(); searchField.setText(""); refreshTable();
    }

    private void deleteSelected() {
        if (editingId == -1) return;
        int confirm = JOptionPane.showConfirmDialog(this, "Delete this customer?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            CustomerDAO.delete(editingId);
            clearForm(); searchField.setText(""); refreshTable();
        }
    }
}