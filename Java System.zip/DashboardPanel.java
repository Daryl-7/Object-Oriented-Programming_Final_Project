package mypackage.System;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;

public class DashboardPanel extends JPanel {

    public DashboardPanel() {
        setLayout(new BorderLayout());
        setBackground(Theme.MAIN_BG);
        build();
    }

    public void build() {
        removeAll();
        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBackground(Theme.MAIN_BG);
        content.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Stat cards
        JPanel stats = new JPanel(new GridLayout(1, 4, 10, 0));
        stats.setBackground(Theme.MAIN_BG);
        stats.setMaximumSize(new Dimension(Integer.MAX_VALUE, 95));
        stats.add(Theme.statCard("Today's Bookings",  String.valueOf(ReservationDAO.countToday()),    "Total reservations", Theme.ACCENT_RED));
        stats.add(Theme.statCard("Guests Expected",   String.valueOf(ReservationDAO.totalGuestsToday()), "Dinner peak: 7 PM", Theme.ACCENT_AMBER));
        stats.add(Theme.statCard("Tables Available",  String.valueOf(TableDAO.countAvailable()),      "of 12 total", Theme.ACCENT_GREEN));
        stats.add(Theme.statCard("Pending Confirm",   String.valueOf(ReservationDAO.countPending()),  "Needs action", Theme.ACCENT_BLUE));
        content.add(stats);
        content.add(Box.createVerticalStrut(20));

        // Section header
        JPanel hdr = new JPanel(new BorderLayout());
        hdr.setBackground(Theme.MAIN_BG);
        hdr.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));
        hdr.add(Theme.sectionTitle("Today's Reservations"), BorderLayout.WEST);
        content.add(hdr);
        content.add(Box.createVerticalStrut(10));

        // Table
        List<Reservation> list = ReservationDAO.getToday();
        String[] cols = {"Table", "Guest Name", "Contact", "Time", "Guests", "Status"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        for (Reservation r : list) {
            model.addRow(new Object[]{
                r.getTableNumber(), r.getGuestName(), r.getContact(),
                r.getTime(), r.getGuests(), r.getStatus()
            });
        }

        StyledTable table = new StyledTable(model);
        table.setStatusColumn(5);
        table.getColumnModel().getColumn(0).setPreferredWidth(55);
        table.getColumnModel().getColumn(1).setPreferredWidth(180);
        table.getColumnModel().getColumn(2).setPreferredWidth(120);
        table.getColumnModel().getColumn(3).setPreferredWidth(80);
        table.getColumnModel().getColumn(4).setPreferredWidth(55);
        table.getColumnModel().getColumn(5).setPreferredWidth(90);

        content.add(table.inScrollPane());

        add(content, BorderLayout.CENTER);
        revalidate();
        repaint();
    }
}