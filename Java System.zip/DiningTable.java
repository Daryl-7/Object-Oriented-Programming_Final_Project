package mypackage.System;

public class DiningTable {
    private String tableNumber;
    private int    capacity;
    private String status;
    private String location;

    public DiningTable(String tableNumber, int capacity, String status, String location) {
        this.tableNumber = tableNumber;
        this.capacity    = capacity;
        this.status      = status;
        this.location    = location;
    }

    public String getTableNumber() { return tableNumber; }
    public int    getCapacity()    { return capacity; }
    public String getStatus()      { return status; }
    public String getLocation()    { return location; }

    public void setStatus(String v)   { status   = v; }
    public void setLocation(String v) { location = v; }
}
