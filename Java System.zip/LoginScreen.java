package mypackage.System;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.geom.RoundRectangle2D;

public class LoginScreen extends JFrame {

    private static final String ADMIN_USER = "admin";
    private static final String ADMIN_PASS = "lamesa123";

    private JTextField fUsername;
    private JPasswordField fPassword;
    private JLabel errorLabel;

    public LoginScreen() {
        setTitle("Login — La Mesa");
        setSize(960, 580);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        add(buildTitlebar(), BorderLayout.NORTH);

        // Split layout: left brand panel + right login card
        JPanel body = new JPanel(new GridLayout(1, 2));
        body.add(buildBrandPanel());
        body.add(buildLoginCard());
        add(body, BorderLayout.CENTER);

        setVisible(true);
    }

    // ----------------------------------------------------------------
    // TITLEBAR
    // ----------------------------------------------------------------
    private JPanel buildTitlebar() {
        JLabel title = new JLabel("La Mesa — Reservation System");
        title.setFont(Theme.F_TITLE);
        title.setForeground(Theme.TEXT_IVORY);

        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(Theme.TITLEBAR);
        bar.setPreferredSize(new Dimension(0, 50));
        bar.setBorder(BorderFactory.createEmptyBorder(10, 30, 10, 30));
        bar.add(title, BorderLayout.WEST);
        return bar;
    }

    // ----------------------------------------------------------------
    // LEFT BRAND PANEL
    // ----------------------------------------------------------------
    private JPanel buildBrandPanel() {
        JPanel panel = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Soft warm gradient background
                GradientPaint gp = new GradientPaint(
                    0, 0, new Color(0x7B1B1B),
                    getWidth(), getHeight(), new Color(0x4A0E0E)
                );
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());

                // Subtle decorative circles
                g2.setColor(new Color(255, 255, 255, 15));
                g2.fillOval(-60, -60, 280, 280);
                g2.fillOval(getWidth() - 100, getHeight() - 100, 220, 220);

                g2.dispose();
            }
        };

        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setOpaque(false);

        // Logo / icon placeholder — elegant fork & knife unicode symbol
        JLabel icon = new JLabel("🍽");
        icon.setFont(new Font("SansSerif", Font.PLAIN, 52));
        icon.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel brandName = new JLabel("La Mesa");
        brandName.setFont(new Font("Serif", Font.BOLD, 36));
        brandName.setForeground(new Color(0xF5ECD7));
        brandName.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel tagline = new JLabel("Fine Dining, Expertly Managed");
        tagline.setFont(new Font("SansSerif", Font.ITALIC, 13));
        tagline.setForeground(new Color(0xD4B896));
        tagline.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Divider line
        JSeparator sep = new JSeparator();
        sep.setMaximumSize(new Dimension(160, 1));
        sep.setForeground(new Color(255, 255, 255, 60));

        // Feature bullets
        String[] features = { "Manage Reservations", "Track Customers", "View Reports" };
        JPanel bullets = new JPanel();
        bullets.setLayout(new BoxLayout(bullets, BoxLayout.Y_AXIS));
        bullets.setOpaque(false);
        for (String f : features) {
            JLabel item = new JLabel("✦  " + f);
            item.setFont(new Font("SansSerif", Font.PLAIN, 12));
            item.setForeground(new Color(0xD4B896));
            item.setAlignmentX(Component.CENTER_ALIGNMENT);
            bullets.add(item);
            bullets.add(Box.createVerticalStrut(6));
        }

        content.add(icon);
        content.add(Box.createVerticalStrut(10));
        content.add(brandName);
        content.add(Box.createVerticalStrut(6));
        content.add(tagline);
        content.add(Box.createVerticalStrut(18));
        content.add(sep);
        content.add(Box.createVerticalStrut(18));
        content.add(bullets);

        panel.add(content);
        return panel;
    }

    // ----------------------------------------------------------------
    // RIGHT LOGIN CARD — fills the entire right half
    // ----------------------------------------------------------------
    private JPanel buildLoginCard() {
        // Use BorderLayout so this panel fills its half completely
        JPanel outer = new JPanel(new BorderLayout());
        outer.setBackground(Theme.CARD_BG);

        // The form sits in a fixed-width inner panel, centered vertically via NORTH/CENTER/SOUTH
        JPanel form = new JPanel();
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
        form.setBackground(Theme.CARD_BG);
        form.setBorder(BorderFactory.createEmptyBorder(60, 60, 60, 60));

        JLabel header = new JLabel("Admin Login");
        header.setFont(new Font("SansSerif", Font.BOLD, 22));
        header.setForeground(Theme.TEXT_DARK);
        header.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel subheader = new JLabel("Sign in to manage reservations");
        subheader.setFont(Theme.F_STAT_SUB);
        subheader.setForeground(Theme.TEXT_MUTED);
        subheader.setAlignmentX(Component.LEFT_ALIGNMENT);

        form.add(Box.createVerticalGlue());
        form.add(header);
        form.add(Box.createVerticalStrut(6));
        form.add(subheader);
        form.add(Box.createVerticalStrut(32));

        JLabel userLabel = Theme.formLabel("Username");
        userLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        fUsername = Theme.inputField();
        fUsername.setAlignmentX(Component.LEFT_ALIGNMENT);
        fUsername.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));

        form.add(userLabel);
        form.add(Box.createVerticalStrut(4));
        form.add(fUsername);
        form.add(Box.createVerticalStrut(16));

        JLabel passLabel = Theme.formLabel("Password");
        passLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        fPassword = new JPasswordField();
        fPassword.setFont(Theme.F_INPUT);
        fPassword.setForeground(Theme.TEXT_DARK);
        fPassword.setBackground(Theme.MAIN_BG);
        fPassword.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Theme.CARD_BORDER, 1),
            BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
        fPassword.setAlignmentX(Component.LEFT_ALIGNMENT);
        fPassword.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));

        KeyAdapter enterKeyListener = new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) attemptLogin();
            }
        };
        fUsername.addKeyListener(enterKeyListener);
        fPassword.addKeyListener(enterKeyListener);

        form.add(passLabel);
        form.add(Box.createVerticalStrut(4));
        form.add(fPassword);
        form.add(Box.createVerticalStrut(10));

        errorLabel = new JLabel(" ");
        errorLabel.setFont(Theme.F_STAT_SUB);
        errorLabel.setForeground(new Color(198, 40, 40));
        errorLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        form.add(errorLabel);
        form.add(Box.createVerticalStrut(10));

        JButton loginBtn = Theme.primaryBtn("Log In");
        loginBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        loginBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        loginBtn.addActionListener(e -> attemptLogin());
        form.add(loginBtn);
        form.add(Box.createVerticalGlue());

        outer.add(form, BorderLayout.CENTER);
        return outer;
    }

    // ----------------------------------------------------------------
    // LOGIN LOGIC
    // ----------------------------------------------------------------
    private void attemptLogin() {
        String user = fUsername.getText().trim();
        String pass = new String(fPassword.getPassword()).trim();

        if (user.isEmpty() || pass.isEmpty()) {
            showError("Please enter both username and password.");
            return;
        }

        if (user.equals(ADMIN_USER) && pass.equals(ADMIN_PASS)) {
            dispose();
            SwingUtilities.invokeLater(() -> new MainFrame());
        } else {
            showError("Invalid username or password.");
            fPassword.setText("");
        }
    }

    private void showError(String message) {
        errorLabel.setText(message);
    }
}