package mypackage.System;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class MainFrame extends JFrame {

    // Nav buttons
    private JButton btnDashboard, btnReservations, btnCustomers, btnTables, btnReports, btnSettings;

    // Nav item panels (hold the strip + button)
    private JPanel navDashboard, navReservations, navCustomers, navTables, navReports, navSettings;

    // Screens
    private DashboardPanel    dashboardPanel;
    private ReservationsPanel reservationsPanel;
    private CustomersPanel    customersPanel;
    private TablesPanel       tablesPanel;
    private ReportPanel       reportPanel;
    private SettingsPanel     settingsPanel;

    // Center card layout
    private JPanel centerCard;
    private CardLayout cardLayout;

    public MainFrame() {
        setTitle("Reservation");
        setSize(960, 580);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        add(buildTitlebar(), BorderLayout.NORTH);
        add(buildSidebar(),  BorderLayout.WEST);
        add(buildCenter(),   BorderLayout.CENTER);

        setVisible(true);
    }

    // ----------------------------------------------------------------
    // TITLEBAR
    // ----------------------------------------------------------------
    private JPanel buildTitlebar() {
        JLabel title = new JLabel("La Mesa — Reservation System");
        title.setFont(Theme.F_TITLE);
        title.setForeground(Theme.TEXT_IVORY);

        String today = LocalDate.now().format(DateTimeFormatter.ofPattern("EEE, MMM dd, yyyy"));
        JLabel date = new JLabel(today);
        date.setFont(Theme.F_DATE);
        date.setForeground(Theme.TEXT_MUTED_TB);

        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(Theme.TITLEBAR);
        bar.setPreferredSize(new Dimension(0, 50));
        bar.setBorder(BorderFactory.createEmptyBorder(10, 30, 10, 30));
        bar.add(title, BorderLayout.WEST);
        bar.add(date,  BorderLayout.EAST);
        return bar;
    }

    // ----------------------------------------------------------------
    // SIDEBAR
    // ----------------------------------------------------------------
    private JPanel buildSidebar() {
        btnDashboard    = Theme.navButton("Dashboard",    true);
        btnReservations = Theme.navButton("Reservations", false);
        btnCustomers    = Theme.navButton("Customers",    false);
        btnTables       = Theme.navButton("Tables",       false);
        btnReports      = Theme.navButton("Reports",      false);
        btnSettings     = Theme.navButton("Settings",     false);

        navDashboard    = Theme.navItem(btnDashboard,    true);
        navReservations = Theme.navItem(btnReservations, false);
        navCustomers    = Theme.navItem(btnCustomers,    false);
        navTables       = Theme.navItem(btnTables,       false);
        navReports      = Theme.navItem(btnReports,      false);
        navSettings     = Theme.navItem(btnSettings,     false);

        // Action listeners
        btnDashboard.addActionListener(e    -> switchTo("dashboard"));
        btnReservations.addActionListener(e -> switchTo("reservations"));
        btnCustomers.addActionListener(e    -> switchTo("customers"));
        btnTables.addActionListener(e       -> switchTo("tables"));
        btnReports.addActionListener(e      -> switchTo("reports"));
        btnSettings.addActionListener(e     -> switchTo("settings"));

        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(Theme.SIDEBAR);
        sidebar.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));

        sidebar.add(navDashboard);
        sidebar.add(Box.createVerticalStrut(8));
        sidebar.add(navReservations);
        sidebar.add(Box.createVerticalStrut(8));
        sidebar.add(navCustomers);
        sidebar.add(Box.createVerticalStrut(8));
        sidebar.add(navTables);
        sidebar.add(Box.createVerticalStrut(8));
        sidebar.add(navReports);
        sidebar.add(Box.createVerticalGlue());
        sidebar.add(navSettings);

        return sidebar;
    }

    // ----------------------------------------------------------------
    // CENTER (CardLayout panels)
    // ----------------------------------------------------------------
    private JPanel buildCenter() {
        cardLayout = new CardLayout();
        centerCard = new JPanel(cardLayout);

        dashboardPanel    = new DashboardPanel();
        reservationsPanel = new ReservationsPanel();
        customersPanel    = new CustomersPanel();
        tablesPanel       = new TablesPanel();
        reportPanel       = new ReportPanel();
        settingsPanel     = new SettingsPanel();

        centerCard.add(dashboardPanel,    "dashboard");
        centerCard.add(reservationsPanel, "reservations");
        centerCard.add(customersPanel,    "customers");
        centerCard.add(tablesPanel,       "tables");
        centerCard.add(reportPanel,       "reports");
        centerCard.add(settingsPanel,     "settings");

        return centerCard;
    }

    // ----------------------------------------------------------------
    // NAVIGATION SWITCH
    // ----------------------------------------------------------------
    private void switchTo(String screen) {
        // Reset all nav items to inactive
        setNavActive(navDashboard,    btnDashboard,    false);
        setNavActive(navReservations, btnReservations, false);
        setNavActive(navCustomers,    btnCustomers,    false);
        setNavActive(navTables,       btnTables,       false);
        setNavActive(navReports,      btnReports,      false);
        setNavActive(navSettings,     btnSettings,     false);

        // Activate the selected one
        switch (screen) {
            case "dashboard":    setNavActive(navDashboard,    btnDashboard,    true); dashboardPanel.build();    break;
            case "reservations": setNavActive(navReservations, btnReservations, true); break;
            case "customers":    setNavActive(navCustomers,    btnCustomers,    true); break;
            case "tables":       setNavActive(navTables,       btnTables,       true); break;
            case "reports":      setNavActive(navReports,      btnReports,      true); break;
            case "settings":     setNavActive(navSettings,     btnSettings,     true); break;
        }

        cardLayout.show(centerCard, screen);
    }

    private void setNavActive(JPanel navItem, JButton btn, boolean active) {
        // Strip is WEST component, button is CENTER
        Component strip = ((BorderLayout) navItem.getLayout()).getLayoutComponent(BorderLayout.WEST);
        strip.setBackground(active ? Theme.NAV_STRIP : Theme.SIDEBAR);
        navItem.setBackground(active ? Theme.NAV_ACTIVE_BG : Theme.SIDEBAR);
        btn.setBackground(active ? Theme.NAV_ACTIVE_BG : Theme.SIDEBAR);
        btn.setForeground(active ? Theme.TEXT_IVORY : Theme.TEXT_NAV_OFF);
        btn.setFont(active ? Theme.F_NAV_ACTIVE : Theme.F_NAV);
    }
}