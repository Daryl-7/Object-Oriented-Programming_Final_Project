package mypackage.System;

import javax.swing.*;
import java.awt.*;
import java.awt.print.*;
import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class ReportPanel extends JPanel {

    private JTextArea reportArea;

    public ReportPanel() {
        setLayout(new BorderLayout());
        setBackground(Theme.MAIN_BG);
        build();
    }

    private void build() {
        JPanel wrapper = new JPanel(new BorderLayout(0, 16));
        wrapper.setBackground(Theme.MAIN_BG);
        wrapper.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Header
        JPanel hdr = new JPanel(new BorderLayout());
        hdr.setBackground(Theme.MAIN_BG);
        hdr.add(Theme.sectionTitle("Reservation Report"), BorderLayout.WEST);

        JPanel btnGroup = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnGroup.setBackground(Theme.MAIN_BG);

        JButton btnGenerate = Theme.secondaryBtn("Generate Report");
        btnGenerate.addActionListener(e -> generateReport());

        JButton btnPrint = Theme.secondaryBtn("Print");
        btnPrint.addActionListener(e -> printReport());

        JButton btnExport = Theme.primaryBtn("Export as .txt");
        btnExport.addActionListener(e -> exportReport());

        btnGroup.add(btnGenerate);
        btnGroup.add(btnPrint);
        btnGroup.add(btnExport);
        hdr.add(btnGroup, BorderLayout.EAST);

        wrapper.add(hdr, BorderLayout.NORTH);

        // Report text area — styled like a printed receipt/report
        reportArea = new JTextArea();
        reportArea.setEditable(false);
        reportArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        reportArea.setForeground(Theme.TEXT_DARK);
        reportArea.setBackground(Theme.CARD_BG);
        reportArea.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
        reportArea.setLineWrap(false);

        JScrollPane scroll = new JScrollPane(reportArea);
        scroll.setBorder(BorderFactory.createLineBorder(Theme.CARD_BORDER, 1));
        scroll.getViewport().setBackground(Theme.CARD_BG);

        wrapper.add(scroll, BorderLayout.CENTER);
        add(wrapper, BorderLayout.CENTER);

        // Auto-generate on first load
        generateReport();
    }

    /**
     * Pulls live data from the DAOs and builds a plain-text report.
     * Kept as plain text (not HTML) so it can be printed or exported easily.
     */
    private void generateReport() {
        StringBuilder sb = new StringBuilder();

        String today = LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, MMMM dd, yyyy"));

        sb.append("====================================================\n");
        sb.append("           LA MESA — RESERVATION SYSTEM REPORT       \n");
        sb.append("====================================================\n");
        sb.append("Generated on: ").append(today).append("\n\n");

        // --- Summary section ---
        int totalToday   = ReservationDAO.countToday();
        int pending       = ReservationDAO.countPending();
        int guestsToday   = ReservationDAO.totalGuestsToday();
        int availableTbls = TableDAO.countAvailable();

        sb.append("---------------- SUMMARY ----------------\n");
        sb.append(String.format("%-28s %d%n", "Total reservations today:", totalToday));
        sb.append(String.format("%-28s %d%n", "Guests expected today:",   guestsToday));
        sb.append(String.format("%-28s %d%n", "Pending confirmations:",   pending));
        sb.append(String.format("%-28s %d%n", "Tables available:",       availableTbls));
        sb.append("\n");

        // --- Reservation list ---
        sb.append("---------------- ALL RESERVATIONS ----------------\n");
        sb.append(String.format("%-4s %-6s %-20s %-12s %-10s %-8s %-7s %-10s%n",
                "ID", "Table", "Guest Name", "Contact", "Date", "Time", "Guests", "Status"));
        sb.append("----------------------------------------------------------------------------------------\n");

        List<Reservation> reservations = ReservationDAO.getAll();
        for (Reservation r : reservations) {
            sb.append(String.format("%-4d %-6s %-20s %-12s %-10s %-8s %-7d %-10s%n",
                    r.getId(), r.getTableNumber(), truncate(r.getGuestName(), 20),
                    r.getContact(), r.getDate(), r.getTime(), r.getGuests(), r.getStatus()));
        }
        sb.append("\n");

        // --- Customers list ---
        sb.append("---------------- CUSTOMERS ----------------\n");
        sb.append(String.format("%-4s %-22s %-14s %-25s %-6s%n",
                "ID", "Name", "Contact", "Email", "Visits"));
        sb.append("----------------------------------------------------------------------\n");

        List<Customer> customers = CustomerDAO.getAll();
        for (Customer c : customers) {
            sb.append(String.format("%-4d %-22s %-14s %-25s %-6d%n",
                    c.getId(), truncate(c.getName(), 22), c.getContact(),
                    truncate(c.getEmail() == null ? "" : c.getEmail(), 25), c.getTotalVisits()));
        }
        sb.append("\n");

        // --- Tables list ---
        sb.append("---------------- DINING TABLES ----------------\n");
        sb.append(String.format("%-10s %-10s %-12s %-10s%n", "Table No.", "Capacity", "Status", "Location"));
        sb.append("----------------------------------------------\n");

        List<DiningTable> tables = TableDAO.getAll();
        for (DiningTable t : tables) {
            sb.append(String.format("%-10s %-10d %-12s %-10s%n",
                    t.getTableNumber(), t.getCapacity(), t.getStatus(), t.getLocation()));
        }

        sb.append("\n====================================================\n");
        sb.append("                  END OF REPORT                     \n");
        sb.append("====================================================\n");

        reportArea.setText(sb.toString());
        reportArea.setCaretPosition(0);
    }

    private String truncate(String s, int max) {
        if (s == null) return "";
        return s.length() > max ? s.substring(0, max - 1) + "…" : s;
    }

    private void printReport() {
        try {
            boolean done = reportArea.print();
            if (!done) {
                JOptionPane.showMessageDialog(this, "Print was cancelled.", "Print", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (PrinterException e) {
            JOptionPane.showMessageDialog(this, "Failed to print report.", "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void exportReport() {
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File("LaMesa_Report.txt"));
        int result = chooser.showSaveDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File file = chooser.getSelectedFile();
            try (PrintWriter writer = new PrintWriter(new FileWriter(file))) {
                writer.print(reportArea.getText());
                JOptionPane.showMessageDialog(this, "Report exported to:\n" + file.getAbsolutePath(),
                        "Export Successful", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Failed to export report.", "Error", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            }
        }
    }
}
