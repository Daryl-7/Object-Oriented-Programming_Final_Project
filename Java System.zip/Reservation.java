package mypackage.System;

public class Reservation {
    private int id;
    private String guestName;
    private String contact;
    private String date;
    private String time;
    private int guests;
    private String tableNumber;
    private String status;

    public Reservation(int id, String guestName, String contact, String date,
                       String time, int guests, String tableNumber, String status) {
        this.id          = id;
        this.guestName   = guestName;
        this.contact     = contact;
        this.date        = date;
        this.time        = time;
        this.guests      = guests;
        this.tableNumber = tableNumber;
        this.status      = status;
    }

    public int    getId()          { return id; }
    public String getGuestName()   { return guestName; }
    public String getContact()     { return contact; }
    public String getDate()        { return date; }
    public String getTime()        { return time; }
    public int    getGuests()      { return guests; }
    public String getTableNumber() { return tableNumber; }
    public String getStatus()      { return status; }

    public void setGuestName(String v)   { guestName   = v; }
    public void setContact(String v)     { contact     = v; }
    public void setDate(String v)        { date        = v; }
    public void setTime(String v)        { time        = v; }
    public void setGuests(int v)         { guests      = v; }
    public void setTableNumber(String v) { tableNumber = v; }
    public void setStatus(String v)      { status      = v; }
}
