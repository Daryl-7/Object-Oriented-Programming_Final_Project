package mypackage.System;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ReservationDAO {

    public static List<Reservation> getAll() {
        List<Reservation> list = new ArrayList<>();
        String sql = "SELECT * FROM reservations ORDER BY date, time";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs   = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public static List<Reservation> getToday() {
        List<Reservation> list = new ArrayList<>();
        String sql = "SELECT * FROM reservations WHERE date = CURDATE() ORDER BY time";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public static boolean add(Reservation r) {
        String sql = "INSERT INTO reservations (guest_name, contact, date, time, guests, table_number, status) VALUES (?,?,?,?,?,?,?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, r.getGuestName());
            ps.setString(2, r.getContact());
            ps.setString(3, r.getDate());
            ps.setString(4, r.getTime());
            ps.setInt   (5, r.getGuests());
            ps.setString(6, r.getTableNumber());
            ps.setString(7, r.getStatus());
            ps.executeUpdate();
            // mark table as reserved
            TableDAO.setStatus(r.getTableNumber(), "Reserved");
            return true;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public static boolean update(Reservation r) {
        String sql = "UPDATE reservations SET guest_name=?, contact=?, date=?, time=?, guests=?, table_number=?, status=? WHERE id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, r.getGuestName());
            ps.setString(2, r.getContact());
            ps.setString(3, r.getDate());
            ps.setString(4, r.getTime());
            ps.setInt   (5, r.getGuests());
            ps.setString(6, r.getTableNumber());
            ps.setString(7, r.getStatus());
            ps.setInt   (8, r.getId());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public static boolean delete(int id) {
        String sql = "DELETE FROM reservations WHERE id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public static int countToday() {
        String sql = "SELECT COUNT(*) FROM reservations WHERE date = CURDATE()";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs   = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    public static int countPending() {
        String sql = "SELECT COUNT(*) FROM reservations WHERE status='Pending'";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs   = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    public static int totalGuestsToday() {
        String sql = "SELECT SUM(guests) FROM reservations WHERE date = CURDATE()";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs   = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    private static Reservation map(ResultSet rs) throws SQLException {
        return new Reservation(
            rs.getInt   ("id"),
            rs.getString("guest_name"),
            rs.getString("contact"),
            rs.getString("date"),
            rs.getString("time"),
            rs.getInt   ("guests"),
            rs.getString("table_number"),
            rs.getString("status")
        );
    }
}
