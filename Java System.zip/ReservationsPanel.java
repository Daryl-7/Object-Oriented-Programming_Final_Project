package mypackage.System;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.List;

public class ReservationsPanel extends JPanel {

    private DefaultTableModel model;
    private StyledTable table;
    private List<Reservation> data;

    // Search
    private JTextField searchField;

    // Form fields
    private JTextField fName, fContact, fDate, fTime, fGuests, fTable;
    private JComboBox<String> fStatus;
    private JButton btnSave, btnClear, btnDelete;
    private int editingId = -1;

    public ReservationsPanel() {
        setLayout(new BorderLayout());
        setBackground(Theme.MAIN_BG);
        build();
    }

    private void build() {
        JPanel wrapper = new JPanel(new BorderLayout(0, 16));
        wrapper.setBackground(Theme.MAIN_BG);
        wrapper.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        wrapper.add(buildTableSection(), BorderLayout.CENTER);
        wrapper.add(buildForm(),         BorderLayout.SOUTH);

        add(wrapper, BorderLayout.CENTER);
    }

    private JPanel buildTableSection() {
        JPanel panel = new JPanel(new BorderLayout(0, 10));
        panel.setBackground(Theme.MAIN_BG);

        // Header row: title + search + refresh
        JPanel hdr = new JPanel(new BorderLayout(10, 0));
        hdr.setBackground(Theme.MAIN_BG);
        hdr.add(Theme.sectionTitle("All Reservations"), BorderLayout.WEST);

        // --- Search bar (center) ---
        searchField = Theme.inputField();
        searchField.setToolTipText("Search by guest name, table no., or status");
        searchField.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                filterTable(searchField.getText().trim());
            }
        });
        JPanel searchWrap = new JPanel(new BorderLayout());
        searchWrap.setBackground(Theme.MAIN_BG);
        searchWrap.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 10));
        searchWrap.add(searchField, BorderLayout.CENTER);
        hdr.add(searchWrap, BorderLayout.CENTER);

        JButton btnRefresh = Theme.secondaryBtn("Refresh");
        btnRefresh.addActionListener(e -> { searchField.setText(""); refreshTable(); });
        hdr.add(btnRefresh, BorderLayout.EAST);
        panel.add(hdr, BorderLayout.NORTH);

        // Table
        String[] cols = {"ID", "Table", "Guest Name", "Contact", "Date", "Time", "Guests", "Status"};
        model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new StyledTable(model);
        table.setStatusColumn(7);
        table.getColumnModel().getColumn(0).setPreferredWidth(35);
        table.getColumnModel().getColumn(1).setPreferredWidth(50);
        table.getColumnModel().getColumn(2).setPreferredWidth(160);
        table.getColumnModel().getColumn(3).setPreferredWidth(110);
        table.getColumnModel().getColumn(4).setPreferredWidth(90);
        table.getColumnModel().getColumn(5).setPreferredWidth(70);
        table.getColumnModel().getColumn(6).setPreferredWidth(50);
        table.getColumnModel().getColumn(7).setPreferredWidth(85);

        // Click row to populate form for editing
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                int row = table.getSelectedRow();
                Reservation r = data.get(row);
                populateForm(r);
            }
        });

        JScrollPane sp = table.inScrollPane();
        sp.setPreferredSize(new Dimension(0, 220));
        panel.add(sp, BorderLayout.CENTER);

        refreshTable();
        return panel;
    }

    private JPanel buildForm() {
        JPanel card = new JPanel(new BorderLayout(0, 12));
        card.setBackground(Theme.CARD_BG);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Theme.CARD_BORDER, 1),
            BorderFactory.createEmptyBorder(14, 16, 14, 16)
        ));

        JPanel titleRow = new JPanel(new BorderLayout());
        titleRow.setBackground(Theme.CARD_BG);
        titleRow.add(Theme.sectionTitle("Add / Edit Reservation"), BorderLayout.WEST);
        card.add(titleRow, BorderLayout.NORTH);

        // Build fields first
        fName    = Theme.inputField();
        fContact = Theme.inputField();
        fDate    = Theme.inputField(); fDate.setToolTipText("YYYY-MM-DD");
        fTime    = Theme.inputField(); fTime.setToolTipText("e.g. 7:00 PM");
        fGuests  = Theme.inputField();
        fTable   = Theme.inputField(); fTable.setToolTipText("e.g. T-04");
        fStatus  = Theme.comboBox(new String[]{"Pending", "Confirmed", "Cancelled"});

        JPanel grid = new JPanel(new GridLayout(2, 4, 14, 10));
        grid.setBackground(Theme.CARD_BG);

        grid.add(fieldBlock("Guest Name",   fName));
        grid.add(fieldBlock("Contact",      fContact));
        grid.add(fieldBlock("Date",         fDate));
        grid.add(fieldBlock("Time",         fTime));
        grid.add(fieldBlock("No. of Guests", fGuests));
        grid.add(fieldBlock("Table No.",    fTable));
        grid.add(fieldBlock("Status",       fStatus));
        grid.add(new JPanel() {{ setBackground(Theme.CARD_BG); }});

        card.add(grid, BorderLayout.CENTER);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setBackground(Theme.CARD_BG);

        btnDelete = Theme.secondaryBtn("Delete");
        btnDelete.setForeground(new Color(198, 40, 40));
        btnDelete.setVisible(false);
        btnDelete.addActionListener(e -> deleteSelected());

        btnClear = Theme.secondaryBtn("Clear");
        btnClear.addActionListener(e -> clearForm());

        btnSave = Theme.primaryBtn("Save Reservation");
        btnSave.addActionListener(e -> saveReservation());

        btnRow.add(btnDelete);
        btnRow.add(btnClear);
        btnRow.add(btnSave);
        card.add(btnRow, BorderLayout.SOUTH);

        return card;
    }

    private JPanel fieldBlock(String labelText, JComponent field) {
        JPanel block = new JPanel();
        block.setLayout(new BoxLayout(block, BoxLayout.Y_AXIS));
        block.setBackground(Theme.CARD_BG);

        JLabel label = Theme.formLabel(labelText);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);

        field.setAlignmentX(Component.LEFT_ALIGNMENT);
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));
        field.setPreferredSize(new Dimension(field.getPreferredSize().width, 30));

        block.add(label);
        block.add(Box.createVerticalStrut(4));
        block.add(field);
        return block;
    }

    private void refreshTable() {
        model.setRowCount(0);
        data = ReservationDAO.getAll();
        for (Reservation r : data) {
            model.addRow(new Object[]{
                r.getId(), r.getTableNumber(), r.getGuestName(), r.getContact(),
                r.getDate(), r.getTime(), r.getGuests(), r.getStatus()
            });
        }
    }

    /**
     * Filters the table in-memory based on guest name, table number, or status.
     * Does not touch the database — just re-renders rows that match.
     */
    private void filterTable(String keyword) {
        model.setRowCount(0);
        String lower = keyword.toLowerCase();
        for (Reservation r : data) {
            boolean matches = keyword.isEmpty()
                || r.getGuestName().toLowerCase().contains(lower)
                || r.getTableNumber().toLowerCase().contains(lower)
                || r.getStatus().toLowerCase().contains(lower)
                || r.getContact().contains(keyword);
            if (matches) {
                model.addRow(new Object[]{
                    r.getId(), r.getTableNumber(), r.getGuestName(), r.getContact(),
                    r.getDate(), r.getTime(), r.getGuests(), r.getStatus()
                });
            }
        }
    }

    private void populateForm(Reservation r) {
        editingId = r.getId();
        fName.setText(r.getGuestName());
        fContact.setText(r.getContact());
        fDate.setText(r.getDate());
        fTime.setText(r.getTime());
        fGuests.setText(String.valueOf(r.getGuests()));
        fTable.setText(r.getTableNumber());
        fStatus.setSelectedItem(r.getStatus());
        btnSave.setText("Update Reservation");
        btnDelete.setVisible(true);
    }

    private void clearForm() {
        editingId = -1;
        fName.setText(""); fContact.setText(""); fDate.setText("");
        fTime.setText(""); fGuests.setText(""); fTable.setText("");
        fStatus.setSelectedIndex(0);
        btnSave.setText("Save Reservation");
        btnDelete.setVisible(false);
        table.clearSelection();
    }

    private void saveReservation() {
        String name    = fName.getText().trim();
        String contact = fContact.getText().trim();
        String date    = fDate.getText().trim();
        String time    = fTime.getText().trim();
        String table   = fTable.getText().trim();
        String status  = fStatus.getSelectedItem().toString();
        int guests;

        if (name.isEmpty() || contact.isEmpty() || date.isEmpty() || time.isEmpty() || table.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Incomplete", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try { guests = Integer.parseInt(fGuests.getText().trim()); }
        catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Guests must be a number.", "Invalid Input", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Reservation r = new Reservation(editingId, name, contact, date, time, guests, table, status);

        if (editingId == -1) {
            ReservationDAO.add(r);
            JOptionPane.showMessageDialog(this, "Reservation added!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } else {
            ReservationDAO.update(r);
            JOptionPane.showMessageDialog(this, "Reservation updated!", "Success", JOptionPane.INFORMATION_MESSAGE);
        }

        clearForm();
        searchField.setText("");
        refreshTable();
    }

    private void deleteSelected() {
        if (editingId == -1) return;
        int confirm = JOptionPane.showConfirmDialog(this,
            "Delete this reservation?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            ReservationDAO.delete(editingId);
            clearForm();
            searchField.setText("");
            refreshTable();
        }
    }
}