package mypackage.System;

import javax.swing.*;
import java.awt.*;

public class SettingsPanel extends JPanel {

    public SettingsPanel() {
        setLayout(new BorderLayout());
        setBackground(Theme.MAIN_BG);
        build();
    }

    private void build() {
        JPanel wrapper = new JPanel();
        wrapper.setLayout(new BoxLayout(wrapper, BoxLayout.Y_AXIS));
        wrapper.setBackground(Theme.MAIN_BG);
        wrapper.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        wrapper.add(Theme.sectionTitle("Settings"));
        wrapper.add(Box.createVerticalStrut(16));

        // DB Connection card
        JPanel dbCard = makeCard("Database Connection");
        JPanel dbGrid = new JPanel(new GridLayout(3, 2, 10, 8));
        dbGrid.setBackground(Theme.CARD_BG);

        JTextField fHost = Theme.inputField(); fHost.setText("localhost");
        JTextField fPort = Theme.inputField(); fPort.setText("3306");
        JTextField fDb   = Theme.inputField(); fDb.setText("lamesa_db");

        dbGrid.add(Theme.formLabel("Host"));     dbGrid.add(fHost);
        dbGrid.add(Theme.formLabel("Port"));     dbGrid.add(fPort);
        dbGrid.add(Theme.formLabel("Database")); dbGrid.add(fDb);

        dbCard.add(dbGrid, BorderLayout.CENTER);

        JPanel dbBtnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        dbBtnRow.setBackground(Theme.CARD_BG);
        JButton testBtn = Theme.primaryBtn("Test Connection");
        testBtn.addActionListener(e -> {
            try {
                DBConnection.getConnection();
                JOptionPane.showMessageDialog(this, "Connected to lamesa_db successfully!", "Connection OK", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Connection failed. Check your MySQL settings.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        dbBtnRow.add(testBtn);
        dbCard.add(dbBtnRow, BorderLayout.SOUTH);
        wrapper.add(dbCard);
        wrapper.add(Box.createVerticalStrut(14));

        // About card
        JPanel aboutCard = makeCard("About");
        JPanel aboutInfo = new JPanel(new GridLayout(3, 1, 0, 6));
        aboutInfo.setBackground(Theme.CARD_BG);

        JLabel app  = new JLabel("La Mesa — Restaurant Reservation System");
        JLabel ver  = new JLabel("Version 1.0");
        JLabel dev  = new JLabel("Built with Java Swing + MySQL");
        app.setFont(Theme.F_TR); app.setForeground(Theme.TEXT_DARK);
        ver.setFont(Theme.F_STAT_LBL); ver.setForeground(Theme.TEXT_MUTED);
        dev.setFont(Theme.F_STAT_LBL); dev.setForeground(Theme.TEXT_MUTED);

        aboutInfo.add(app); aboutInfo.add(ver); aboutInfo.add(dev);
        aboutCard.add(aboutInfo, BorderLayout.CENTER);
        wrapper.add(aboutCard);

        add(new JScrollPane(wrapper), BorderLayout.CENTER);
    }

    private JPanel makeCard(String title) {
        JPanel card = new JPanel(new BorderLayout(0, 10));
        card.setBackground(Theme.CARD_BG);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Theme.CARD_BORDER, 1),
            BorderFactory.createEmptyBorder(14, 16, 14, 16)
        ));
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 200));
        card.add(Theme.sectionTitle(title), BorderLayout.NORTH);
        return card;
    }
}
