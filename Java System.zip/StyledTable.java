package mypackage.System;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;

public class StyledTable extends JTable {

    public StyledTable(DefaultTableModel model) {
        super(model);
        setFont(Theme.F_TR);
        setForeground(Theme.TEXT_DARK);
        setBackground(Theme.CARD_BG);
        setRowHeight(36);
        setShowGrid(false);
        setIntercellSpacing(new Dimension(0, 0));
        setSelectionBackground(Theme.ROW_HOVER);
        setSelectionForeground(Theme.TEXT_DARK);
        setFocusable(false);
        getTableHeader().setReorderingAllowed(false);
        styleHeader();
        setPaddingRenderer();
    }

    private void styleHeader() {
        JTableHeader h = getTableHeader();
        h.setFont(Theme.F_TH);
        h.setBackground(Theme.TABLE_HEADER);
        h.setForeground(Theme.TEXT_MUTED);
        h.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Theme.CARD_BORDER));
    }

    private void setPaddingRenderer() {
        DefaultTableCellRenderer r = new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable t, Object val, boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t, val, sel, foc, row, col);
                setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
                setBackground(sel ? Theme.ROW_HOVER : Theme.CARD_BG);
                setForeground(Theme.TEXT_DARK);
                return this;
            }
        };
        for (int i = 0; i < getColumnCount(); i++) {
            getColumnModel().getColumn(i).setCellRenderer(r);
        }
    }

    public void setStatusColumn(int colIndex) {
        getColumnModel().getColumn(colIndex).setCellRenderer(new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable t, Object val, boolean sel, boolean foc, int row, int col) {
                JLabel lbl = new JLabel(val != null ? val.toString() : "");
                lbl.setFont(Theme.F_BADGE);
                lbl.setOpaque(true);
                lbl.setBackground(sel ? Theme.ROW_HOVER : Theme.CARD_BG);
                lbl.setForeground(Theme.statusFg(val != null ? val.toString() : ""));
                lbl.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
                return lbl;
            }
        });
    }

    public JScrollPane inScrollPane() {
        JScrollPane sp = new JScrollPane(this);
        sp.setBorder(BorderFactory.createLineBorder(Theme.CARD_BORDER, 1));
        sp.getViewport().setBackground(Theme.CARD_BG);
        return sp;
    }
}
