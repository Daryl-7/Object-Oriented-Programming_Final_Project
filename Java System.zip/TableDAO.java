package mypackage.System;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TableDAO {

    public static List<DiningTable> getAll() {
        List<DiningTable> list = new ArrayList<>();
        String sql = "SELECT * FROM dining_tables ORDER BY table_number";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs   = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public static int countAvailable() {
        String sql = "SELECT COUNT(*) FROM dining_tables WHERE status='Available'";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs   = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    public static boolean setStatus(String tableNumber, String status) {
        String sql = "UPDATE dining_tables SET status=? WHERE table_number=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setString(2, tableNumber);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public static boolean update(DiningTable t) {
        String sql = "UPDATE dining_tables SET capacity=?, status=?, location=? WHERE table_number=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt   (1, t.getCapacity());
            ps.setString(2, t.getStatus());
            ps.setString(3, t.getLocation());
            ps.setString(4, t.getTableNumber());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    private static DiningTable map(ResultSet rs) throws SQLException {
        return new DiningTable(
            rs.getString("table_number"),
            rs.getInt   ("capacity"),
            rs.getString("status"),
            rs.getString("location")
        );
    }
}
