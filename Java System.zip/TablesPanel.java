package mypackage.System;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;

public class TablesPanel extends JPanel {

    private DefaultTableModel model;
    private StyledTable table;
    private List<DiningTable> data;

    private JTextField fCapacity, fLocation;
    private JComboBox<String> fStatus;
    private JLabel fTableNo;
    private JButton btnSave, btnClear;
    private String editingTable = null;

    public TablesPanel() {
        setLayout(new BorderLayout());
        setBackground(Theme.MAIN_BG);
        build();
    }

    private void build() {
        JPanel wrapper = new JPanel(new BorderLayout(0, 16));
        wrapper.setBackground(Theme.MAIN_BG);
        wrapper.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        wrapper.add(buildTableSection(), BorderLayout.CENTER);
        wrapper.add(buildForm(),         BorderLayout.SOUTH);
        add(wrapper, BorderLayout.CENTER);
    }

    private JPanel buildTableSection() {
        JPanel panel = new JPanel(new BorderLayout(0, 10));
        panel.setBackground(Theme.MAIN_BG);

        JPanel hdr = new JPanel(new BorderLayout());
        hdr.setBackground(Theme.MAIN_BG);
        hdr.add(Theme.sectionTitle("Dining Tables"), BorderLayout.WEST);
        JButton btnRefresh = Theme.secondaryBtn("Refresh");
        btnRefresh.addActionListener(e -> refreshTable());
        hdr.add(btnRefresh, BorderLayout.EAST);
        panel.add(hdr, BorderLayout.NORTH);

        String[] cols = {"Table No.", "Capacity", "Status", "Location"};
        model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new StyledTable(model);
        table.setStatusColumn(2);
        table.getColumnModel().getColumn(0).setPreferredWidth(80);
        table.getColumnModel().getColumn(1).setPreferredWidth(80);
        table.getColumnModel().getColumn(2).setPreferredWidth(100);
        table.getColumnModel().getColumn(3).setPreferredWidth(120);

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                DiningTable t = data.get(table.getSelectedRow());
                populateForm(t);
            }
        });

        JScrollPane sp = table.inScrollPane();
        sp.setPreferredSize(new Dimension(0, 270));
        panel.add(sp, BorderLayout.CENTER);
        refreshTable();
        return panel;
    }

    private JPanel buildForm() {
        JPanel card = new JPanel(new BorderLayout(0, 12));
        card.setBackground(Theme.CARD_BG);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Theme.CARD_BORDER, 1),
            BorderFactory.createEmptyBorder(14, 16, 14, 16)
        ));

        JPanel titleRow = new JPanel(new BorderLayout());
        titleRow.setBackground(Theme.CARD_BG);
        titleRow.add(Theme.sectionTitle("Edit Table"), BorderLayout.WEST);
        card.add(titleRow, BorderLayout.NORTH);

        JPanel grid = new JPanel(new GridLayout(2, 4, 10, 8));
        grid.setBackground(Theme.CARD_BG);

        fTableNo  = new JLabel("—");
        fTableNo.setFont(Theme.F_INPUT);
        fTableNo.setForeground(Theme.TEXT_DARK);

        fCapacity = Theme.inputField();
        fLocation = Theme.inputField();
        fStatus   = Theme.comboBox(new String[]{"Available", "Reserved"});

        grid.add(Theme.formLabel("Table No."));  grid.add(Theme.formLabel("Capacity"));
        grid.add(Theme.formLabel("Status"));     grid.add(Theme.formLabel("Location"));
        grid.add(fTableNo); grid.add(fCapacity); grid.add(fStatus); grid.add(fLocation);

        card.add(grid, BorderLayout.CENTER);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setBackground(Theme.CARD_BG);

        btnClear = Theme.secondaryBtn("Clear");
        btnClear.addActionListener(e -> clearForm());

        btnSave = Theme.primaryBtn("Update Table");
        btnSave.addActionListener(e -> saveTable());

        btnRow.add(btnClear); btnRow.add(btnSave);
        card.add(btnRow, BorderLayout.SOUTH);

        return card;
    }

    private void refreshTable() {
        model.setRowCount(0);
        data = TableDAO.getAll();
        for (DiningTable t : data) {
            model.addRow(new Object[]{t.getTableNumber(), t.getCapacity(), t.getStatus(), t.getLocation()});
        }
    }

    private void populateForm(DiningTable t) {
        editingTable = t.getTableNumber();
        fTableNo.setText(t.getTableNumber());
        fCapacity.setText(String.valueOf(t.getCapacity()));
        fStatus.setSelectedItem(t.getStatus());
        fLocation.setText(t.getLocation());
    }

    private void clearForm() {
        editingTable = null;
        fTableNo.setText("—");
        fCapacity.setText("");
        fLocation.setText("");
        fStatus.setSelectedIndex(0);
        table.clearSelection();
    }

    private void saveTable() {
        if (editingTable == null) {
            JOptionPane.showMessageDialog(this, "Select a table from the list first.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int cap;
        try { cap = Integer.parseInt(fCapacity.getText().trim()); }
        catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Capacity must be a number.", "Invalid", JOptionPane.WARNING_MESSAGE);
            return;
        }
        DiningTable t = new DiningTable(editingTable, cap,
            fStatus.getSelectedItem().toString(), fLocation.getText().trim());
        TableDAO.update(t);
        JOptionPane.showMessageDialog(this, "Table updated!", "Success", JOptionPane.INFORMATION_MESSAGE);
        clearForm(); refreshTable();
    }
}
