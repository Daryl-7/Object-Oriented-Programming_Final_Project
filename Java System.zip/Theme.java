package mypackage.System;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class Theme {

    // Backgrounds
    public static final Color TITLEBAR      = new Color(0x6B1E1E);
    public static final Color SIDEBAR       = new Color(0x3D1010);
    public static final Color NAV_ACTIVE_BG = new Color(0x521818);
    public static final Color NAV_STRIP     = new Color(0xC98A2E);
    public static final Color MAIN_BG       = new Color(0xF5EDE0);
    public static final Color CARD_BG       = new Color(0xFFFBF6);
    public static final Color CARD_BORDER   = new Color(0xE2CEB4);
    public static final Color TABLE_HEADER  = new Color(0xF0E4D0);
    public static final Color ROW_HOVER     = new Color(0xFDF5EC);
    public static final Color SECTION_BG    = new Color(0xFAF3EA);

    // Text
    public static final Color TEXT_IVORY    = new Color(0xF9F0E6);
    public static final Color TEXT_MUTED_TB = new Color(0xC8B9A8);
    public static final Color TEXT_NAV_OFF  = new Color(0xB9A890);
    public static final Color TEXT_DARK     = new Color(0x2E1A0E);
    public static final Color TEXT_MUTED    = new Color(0x9B7355);
    public static final Color ACCENT_GOLD   = new Color(0xC98A2E);
    public static final Color BTN_PRIMARY   = new Color(0x7B1B1B);
    public static final Color BTN_HOVER     = new Color(0x5C1212);

    // Stat card accent colors (one per card slot)
    public static final Color ACCENT_RED    = new Color(0x7B1B1B);
    public static final Color ACCENT_AMBER  = new Color(0xC98A2E);
    public static final Color ACCENT_GREEN  = new Color(0x2E7D32);
    public static final Color ACCENT_BLUE   = new Color(0x1565C0);

    // Status colors
    public static final Color CONFIRMED_BG  = new Color(0xE8F5E9);
    public static final Color CONFIRMED_FG  = new Color(0x2E7D32);
    public static final Color PENDING_BG    = new Color(0xFFF8E1);
    public static final Color PENDING_FG    = new Color(0xF57F17);
    public static final Color CANCELLED_BG  = new Color(0xFFEBEE);
    public static final Color CANCELLED_FG  = new Color(0xC62828);
    public static final Color AVAILABLE_BG  = new Color(0xE8F5E9);
    public static final Color AVAILABLE_FG  = new Color(0x2E7D32);
    public static final Color RESERVED_BG   = new Color(0xFFF8E1);
    public static final Color RESERVED_FG   = new Color(0xF57F17);

    // Fonts — use Serif for headings to feel more upscale
    public static final Font F_TITLE      = new Font("Serif",     Font.BOLD,  16);
    public static final Font F_DATE       = new Font("SansSerif", Font.PLAIN, 12);
    public static final Font F_NAV        = new Font("SansSerif", Font.PLAIN, 13);
    public static final Font F_NAV_ACTIVE = new Font("SansSerif", Font.BOLD,  13);
    public static final Font F_SECTION    = new Font("Serif",     Font.BOLD,  15);
    public static final Font F_STAT_LBL   = new Font("SansSerif", Font.BOLD,  10);
    public static final Font F_STAT_VAL   = new Font("Serif",     Font.BOLD,  26);
    public static final Font F_STAT_SUB   = new Font("SansSerif", Font.PLAIN, 11);
    public static final Font F_TH         = new Font("SansSerif", Font.BOLD,  11);
    public static final Font F_TR         = new Font("SansSerif", Font.PLAIN, 12);
    public static final Font F_LABEL      = new Font("SansSerif", Font.BOLD,  11);
    public static final Font F_INPUT      = new Font("SansSerif", Font.PLAIN, 13);
    public static final Font F_BTN        = new Font("SansSerif", Font.BOLD,  12);
    public static final Font F_BADGE      = new Font("SansSerif", Font.BOLD,  10);

    // --- Component builders ---

    public static JButton navButton(String text, boolean active) {
        JButton btn = new JButton(text);
        btn.setFont(active ? F_NAV_ACTIVE : F_NAV);
        btn.setForeground(active ? TEXT_IVORY : TEXT_NAV_OFF);
        btn.setBackground(active ? NAV_ACTIVE_BG : SIDEBAR);
        btn.setOpaque(true);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(true);
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setBorder(BorderFactory.createEmptyBorder(0, 16, 0, 0));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    public static JPanel navItem(JButton btn, boolean active) {
        JPanel strip = new JPanel();
        strip.setBackground(active ? NAV_STRIP : SIDEBAR);
        strip.setPreferredSize(new Dimension(4, 0));

        JPanel item = new JPanel(new BorderLayout());
        item.setPreferredSize(new Dimension(160, 40));
        item.setMaximumSize(new Dimension(160, 40));
        item.setMinimumSize(new Dimension(160, 40));
        item.setBackground(active ? NAV_ACTIVE_BG : SIDEBAR);
        item.add(strip, BorderLayout.WEST);
        item.add(btn,   BorderLayout.CENTER);
        return item;
    }

    /**
     * Richer stat card: colored top accent bar + icon emoji + value + label
     */
    public static JPanel statCard(String label, String value, String sub, Color accent) {
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setBackground(CARD_BG);
        wrapper.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(CARD_BORDER, 1),
            BorderFactory.createEmptyBorder(0, 0, 0, 0)
        ));

        // Colored top accent bar
        JPanel bar = new JPanel();
        bar.setBackground(accent);
        bar.setPreferredSize(new Dimension(0, 4));
        wrapper.add(bar, BorderLayout.NORTH);

        // Card body
        JPanel body = new JPanel();
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setBackground(CARD_BG);
        body.setBorder(BorderFactory.createEmptyBorder(12, 16, 12, 16));

        JLabel lbl = new JLabel(label.toUpperCase());
        lbl.setFont(F_STAT_LBL);
        lbl.setForeground(TEXT_MUTED);
        lbl.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel val = new JLabel(value);
        val.setFont(F_STAT_VAL);
        val.setForeground(accent);
        val.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel subLbl = new JLabel(sub);
        subLbl.setFont(F_STAT_SUB);
        subLbl.setForeground(TEXT_MUTED);
        subLbl.setAlignmentX(Component.LEFT_ALIGNMENT);

        body.add(lbl);
        body.add(Box.createVerticalStrut(6));
        body.add(val);
        body.add(Box.createVerticalStrut(2));
        body.add(subLbl);

        wrapper.add(body, BorderLayout.CENTER);
        return wrapper;
    }

    /** Overload for backward compat — uses ACCENT_GOLD by default */
    public static JPanel statCard(String label, String value, String sub) {
        return statCard(label, value, sub, ACCENT_GOLD);
    }

    public static JButton primaryBtn(String text) {
        JButton b = new JButton(text);
        b.setFont(F_BTN);
        b.setForeground(TEXT_IVORY);
        b.setBackground(BTN_PRIMARY);
        b.setOpaque(true);
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 20));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    public static JButton secondaryBtn(String text) {
        JButton b = new JButton(text);
        b.setFont(F_BTN);
        b.setForeground(TEXT_MUTED);
        b.setBackground(CARD_BG);
        b.setOpaque(true);
        b.setFocusPainted(false);
        b.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(CARD_BORDER, 1),
            BorderFactory.createEmptyBorder(7, 16, 7, 16)
        ));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    public static JTextField inputField() {
        JTextField f = new JTextField();
        f.setFont(F_INPUT);
        f.setForeground(TEXT_DARK);
        f.setBackground(new Color(0xFFFBF6));
        f.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(CARD_BORDER, 1),
            BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
        return f;
    }

    public static JComboBox<String> comboBox(String[] options) {
        JComboBox<String> cb = new JComboBox<>(options);
        cb.setFont(F_INPUT);
        cb.setForeground(TEXT_DARK);
        cb.setBackground(new Color(0xFFFBF6));
        cb.setBorder(BorderFactory.createLineBorder(CARD_BORDER, 1));
        return cb;
    }

    public static JLabel formLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(F_LABEL);
        l.setForeground(TEXT_MUTED);
        return l;
    }

    public static JLabel sectionTitle(String text) {
        JLabel l = new JLabel(text);
        l.setFont(F_SECTION);
        l.setForeground(TEXT_DARK);
        return l;
    }

    public static Color statusBg(String s) {
        switch (s) {
            case "Confirmed": return CONFIRMED_BG;
            case "Pending":   return PENDING_BG;
            case "Cancelled": return CANCELLED_BG;
            case "Available": return AVAILABLE_BG;
            case "Reserved":  return RESERVED_BG;
            default:          return CARD_BG;
        }
    }

    public static Color statusFg(String s) {
        switch (s) {
            case "Confirmed": return CONFIRMED_FG;
            case "Pending":   return PENDING_FG;
            case "Cancelled": return CANCELLED_FG;
            case "Available": return AVAILABLE_FG;
            case "Reserved":  return RESERVED_FG;
            default:          return TEXT_DARK;
        }
    }
}